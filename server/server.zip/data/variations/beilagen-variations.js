module.exports = [
    {
        id: "addon",
        name: "Addon",
        options: [
            {
                id: "truffelol",
                name: "Truffelöl",
                price: 2,
                parent: "addon",
            }
        ]
    }
]